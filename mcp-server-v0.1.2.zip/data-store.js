"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DataStore = void 0;
const node_crypto_1 = require("node:crypto");
class DataStore {
    items = new Map();
    order = [];
    MAX_CAPACITY = 20;
    /**
     * Store captured element data, generating a UUID v4 as unique ID.
     * Evicts the oldest record when capacity exceeds MAX_CAPACITY.
     */
    store(data) {
        const id = (0, node_crypto_1.randomUUID)();
        const record = { ...data, id };
        this.items.set(id, record);
        this.order.push(id);
        // Evict oldest records when over capacity
        while (this.order.length > this.MAX_CAPACITY) {
            const oldestId = this.order.shift();
            this.items.delete(oldestId);
        }
        return id;
    }
    /** Get a record by its unique ID. */
    getById(id) {
        return this.items.get(id) ?? null;
    }
    /** Get the most recently stored record. */
    getLatest() {
        if (this.order.length === 0)
            return null;
        const latestId = this.order[this.order.length - 1];
        return this.items.get(latestId) ?? null;
    }
    /** List summaries of all cached records. */
    list() {
        return this.order.map((id) => {
            const item = this.items.get(id);
            return {
                id: item.id,
                timestamp: item.timestamp,
                url: item.url,
                tagName: item.element.tagName,
                classes: item.element.classes,
                text: item.element.text.length > 100
                    ? item.element.text.slice(0, 100) + '...'
                    : item.element.text,
            };
        });
    }
    /** Clear all cached data. */
    clear() {
        this.items.clear();
        this.order = [];
    }
}
exports.DataStore = DataStore;
//# sourceMappingURL=data-store.js.map
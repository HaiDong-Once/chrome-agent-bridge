#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mcp_js_1 = require("@modelcontextprotocol/sdk/server/mcp.js");
const stdio_js_1 = require("@modelcontextprotocol/sdk/server/stdio.js");
const data_store_js_1 = require("./data-store.js");
const http_server_js_1 = require("./http-server.js");
const mcp_tools_js_1 = require("./mcp-tools.js");
const HTTP_PORT = 19816;
async function main() {
    // Shared DataStore instance used by both HTTP Server and MCP Tools
    const dataStore = new data_store_js_1.DataStore();
    // Start HTTP Server for receiving data from Chrome Extension
    const httpServer = new http_server_js_1.HttpServer(dataStore);
    try {
        await httpServer.start(HTTP_PORT);
    }
    catch (err) {
        const code = err.code;
        if (code === 'EADDRINUSE') {
            process.stderr.write(`错误: 端口 ${HTTP_PORT} 已被占用，请关闭占用该端口的进程后重试。\n`);
            process.exit(1);
        }
        throw err;
    }
    // Initialize MCP Server with stdio transport
    const mcpServer = new mcp_js_1.McpServer({
        name: 'chrome-agent-bridge',
        version: '0.1.0',
    });
    (0, mcp_tools_js_1.registerTools)(mcpServer, dataStore);
    const transport = new stdio_js_1.StdioServerTransport();
    await mcpServer.connect(transport);
}
main().catch((err) => {
    process.stderr.write(`启动失败: ${String(err)}\n`);
    process.exit(1);
});
//# sourceMappingURL=index.js.map
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpServer = void 0;
const http = __importStar(require("node:http"));
const validator_js_1 = require("./validator.js");
const CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
};
class HttpServer {
    dataStore;
    server = null;
    constructor(dataStore) {
        this.dataStore = dataStore;
    }
    /**
     * Start the HTTP server listening on localhost at the given port.
     */
    start(port) {
        return new Promise((resolve, reject) => {
            this.server = http.createServer((req, res) => {
                this.handleRequest(req, res);
            });
            this.server.on('error', (err) => {
                reject(err);
            });
            this.server.listen(port, '127.0.0.1', () => {
                resolve();
            });
        });
    }
    /**
     * Stop the HTTP server.
     */
    stop() {
        return new Promise((resolve, reject) => {
            if (!this.server) {
                resolve();
                return;
            }
            this.server.close((err) => {
                if (err)
                    reject(err);
                else
                    resolve();
            });
        });
    }
    handleRequest(req, res) {
        // Handle CORS preflight
        if (req.method === 'OPTIONS') {
            this.sendJson(res, 204, null);
            return;
        }
        const url = req.url ?? '/';
        if (req.method === 'GET' && url === '/ping') {
            const response = this.handlePing();
            this.sendJson(res, 200, response);
            return;
        }
        if (req.method === 'POST' && url === '/capture') {
            this.readBody(req)
                .then((body) => this.handleCapture(body))
                .then(({ status, body }) => {
                this.sendJson(res, status, body);
            })
                .catch(() => {
                const errorResponse = { success: false, error: 'Invalid JSON' };
                this.sendJson(res, 400, errorResponse);
            });
            return;
        }
        // Unknown route
        this.sendJson(res, 404, { error: 'Not found' });
    }
    /**
     * Handle GET /ping — health check endpoint.
     */
    handlePing() {
        return { status: 'ok', timestamp: Date.now() };
    }
    /**
     * Handle POST /capture — validate and store captured element data.
     */
    handleCapture(body) {
        const validation = (0, validator_js_1.validateCapturedElementData)(body);
        if (!validation.valid) {
            return {
                status: 400,
                body: { success: false, error: validation.errors.join('; ') },
            };
        }
        const id = this.dataStore.store(body);
        return {
            status: 200,
            body: { success: true, id },
        };
    }
    readBody(req) {
        return new Promise((resolve, reject) => {
            const chunks = [];
            req.on('data', (chunk) => chunks.push(chunk));
            req.on('end', () => {
                try {
                    const raw = Buffer.concat(chunks).toString('utf-8');
                    resolve(JSON.parse(raw));
                }
                catch {
                    reject(new Error('Invalid JSON'));
                }
            });
            req.on('error', reject);
        });
    }
    sendJson(res, statusCode, body) {
        for (const [key, value] of Object.entries(CORS_HEADERS)) {
            res.setHeader(key, value);
        }
        if (body === null) {
            res.writeHead(statusCode);
            res.end();
            return;
        }
        res.setHeader('Content-Type', 'application/json');
        res.writeHead(statusCode);
        res.end(JSON.stringify(body));
    }
}
exports.HttpServer = HttpServer;
//# sourceMappingURL=http-server.js.map